
<?php
require_once 'core/init.php';


$id = Input::get('id');
//$id = 1;
$user = new Branch($id);


/*
SELECT ba.id  FROM `branch` b
INNER JOIN `branch_additionals` ba ON b.id = ba.branch_id
WHERE b.id = 1;
*/


$data = DB::getInstance()->query("SELECT ba.id FROM branch b 
	INNER JOIN branch_additionals ba ON b.id = ba.branch_id 
	WHERE b.id = $id;");

if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	$output .= "
	<tr>
	    <td>This client is not found in our clients table records</td>
	</tr>
	";

}else{
   
	foreach( $data->results() as $result ){
		$result->id;
	
	}

}

$branch_add = new BranchAdditionals($result->id);




if( Input::exists() ){
	if( Token::check( Input::get('token') ) ){

		$output = "";

		$validate = new Validate();
		$validate = $validate->check( $_POST, array(
				

				'invoice_no' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50

					//'unique'   => 'users'
					
				),
				'branch_name' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50

					//'unique'   => 'users'
					
				),
				'branch_code' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50

					//'unique'   => 'users'
					
				),
				'branch_contact' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50

					//'unique'   => 'users'
					
				),
				'branch_email' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 60,
					'valid_email'  => true,
					//'unique'   => 'branch'

					//'max'	   => 50,
					//'unique'   => 'users'
					
				),
				'registered_name' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'emp_email' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 60,
					'valid_email'  => true,
					//'unique'   => 'branch'

					//'max'	   => 50,
					//'unique'   => 'users'
					
				),
				'emp_contact_number' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50

					//'unique'   => 'users'
					
				),
				'address_line1' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50

					//'unique'   => 'users'
					
				),
				'address_line2' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50

					//'unique'   => 'users'
					
				),
				'address_line3' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50

					//'unique'   => 'users'
					
				),
				'address_line4' => array(

					//'required' => true,
					'min' 	   => 2,
					'max'	   => 50

					//'unique'   => 'users'
					
				)
				

		) );

	
		if( $validate->passed() ){
			 #Update a user

			try{
				

				$user->update( array(	

					'invoice_no'    	=> Input::get('invoice_no'),
					'branch_name'		  	=> Input::get('branch_name'),
					'branch_code'	  	=> Input::get('branch_code'),
					'branch_contact'	  	=>  Input::get('branch_contact'),
					'branch_email'        	=> Input::get('branch_email')
					
				

				), $id );

				#GET THE branch_additionals = id

				$branch_add->update(   array(	

					'registered_name'    	=> Input::get('registered_name'),
					'emp_email'		  		=> Input::get('emp_email'),
					'emp_contact_number'	=> Input::get('emp_contact_number'),
					'address_line1'	  		=>  Input::get('address_line1'),
					'address_line2'	  		=>  Input::get('address_line2'),
					'address_line3'	  		=>  Input::get('address_line3'),
					'address_line4'        	=> Input::get('address_line4')
					

				), $branch_add->data()->id );


				Redirect::to('index.php');

			}catch( Exception $e ){
				die( $e->getMessage() );
			} 

		

		}else{

			#Output errorrs
			foreach( $validate->errors() as $error ){
				$output .= $error . '.<br/>';
				Session::put( 'output', "<div class='alert alert-danger'>" . $output . "</div>" );
			}
		

		}



	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>

	<!-- # NAV -->
	<nav class="nav navbar-inverse">
		<div class="container">
			
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">Advanced Intelligence System</a>
			</div>

			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav" id="_links">
		
					<li class=""><a href="index.php">Home</a></li>
					<li class=""><a href="register.php">Add User</a></li>
					<li class=""><a href="">Add Client</a></li>
					<li class=""><a href="billing.php">Billing</a></li>
					

				</ul>
			</div>

		</div>
	</nav>



	<!-- # CONTAINER -->
	<div class="container container-bg">
		<div class="row">

			<div class="col-md-12">
			    <p>
					<div class="well border-color">
					<!-- # WELL <div class="well"> -->

						 <div id="results" class="text-center">
					 		 <?php
					 		   if( Session::exists('output') ){
					 		   	   echo  Session::flash('output');

								}
					 		 ?>
					   	 </div>

						 <!-- ADD THE TABLE OUTSIDE -->
						 <table class="table">
						 		<thead class="thead-dark">
						 			<tr>
						 			    <!-- # NOTE MINIMIZE THIS AS SCREEN DECREASES -->
						 				<th colspan="2" ><h3>Update Client Details:</h3></th>
						 			</tr>
						 		</thead>

						 		<!--
						 		<tbody>

						 			<tr>
						 				<td colspan="2">
						 					<button type="reset" value="Reset" class="btn btn-warning btn-block">Clear Form</button>
						 				</td>
						 			</tr>	


						 		</tbody>
						 	-->

						</table>



						 <ul class="list-group">
					   	 <li class="list-group-item">


					   	 <!-- #ADD IMAGE HERE-->
					   	  <img class="img-fluid img-rounded" src="images/bi2.png" style="width: 100%;height: 95px;">
					   	


						<!-- <hr/> -->


					   	
					   	

						 <form action="" method="post" id="register_form">

						 	<table class="table">

						 		
						 		<thead class="thead-dark">
						 			<tr>
						 				<th colspan="2" ></th>
						 			</tr>
						 		</thead>

						 		<tbody>
						 			<tr>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Invoice No:</label>
							   	  	 			
							   	  	 			
							   	  	 			<input type="text" name="invoice_no" id="invoice_no" value="<?php echo escape( $user->data()->invoice_no ); ?>" class="form-control border-color">
							   	  	 	
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Company Name:</label>
							   	  	 			<input type="text" name="branch_name" id="branch_name"  value="<?php echo escape( $user->data()->branch_name ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>

						 			<tr>
						 				<td colspan="2">
						 					<div class="form-group">
							   	  	 			<label>Company Code:</label>
							   	  	 			<input type="text" name="branch_code" id="branch_code"  value="<?php echo escape( $user->data()->branch_code ); ?>" class="form-control border-color">
							   	  	 		</div>
						 				</td>
						 			</tr>

						 			
						 			<tr>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Contact No:</label>
							   	  	 			<input type="text" name="branch_contact" id="branch_contact" value="<?php echo escape( $user->data()->branch_contact ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Email:</label>
							   	  	 			<input type="text" name="branch_email" id="branch_email"  value="<?php echo escape( $user->data()->branch_email ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>

									
						 			<tr>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Registered Name:</label>
							   	  	 			<input type="text" name="registered_name" id="registered_name" value="<?php echo escape( $branch_add->data()->registered_name ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Employee Email:</label>
							   	  	 			<input type="text" name="emp_email" id="emp_email"  value="<?php echo escape( $branch_add->data()->emp_email ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>


						 			<tr>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Employee Contact No:</label>
							   	  	 			<input type="text" name="emp_contact_number" id="emp_contact_number" value="<?php echo escape( $branch_add->data()->emp_contact_number ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Address Line 1:</label>
							   	  	 			<input type="text" name="address_line1" id="address_line1"  value="<?php echo escape( $branch_add->data()->address_line1 ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>

						 			<tr>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Address Line 2:</label>
							   	  	 			<input type="text" name="address_line2" id="address_line2" value="<?php echo escape( $branch_add->data()->address_line2 ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Address Line 3:</label>
							   	  	 			<input type="text" name="address_line3" id="address_line3"  value="<?php echo escape( $branch_add->data()->address_line3 ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>


						 			<tr>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Address Line 4:</label>
							   	  	 			<input type="text" name="address_line4" id="address_line4" value="<?php echo escape( $branch_add->data()->address_line4 ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	

						 			</tr>


						 			

						 			<tr>
							   	  	 	<td colspan="2">
							   	  	 		<div class="form-group">
							   	  	 		    <input type="hidden" name="token" value="<?php echo Token::generate(); ?>">
							   	  	 			<input type="hidden" name="action" id="action" value="" >
							   	  	 			<input type="submit" name="register" id="register" value="Update" class="btn btn-primary btn-block">
							   	  	 		</div>
							   	  	 	</td>
							   	  	 </tr>

						 		</tbody>
						 	</table>
					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>
			</div>			

		</div>
	</div>

	<!-- # FOOTER -->
	
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S</p>
	</footer>

</body>
</html>

<!-- Search for People -->
<script type="text/javascript">
$(document).ready( function(){
        
	//ADD HERE, MAYBE IF I CHOOSE TO VALIDATE THIS SIDE


} );

</script>