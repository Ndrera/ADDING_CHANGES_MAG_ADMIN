<?php
require_once 'core/init.php';
require('fpdf182/fpdf.php');



//CREATING AN INVOICE TABLE DATA
//echo "APPROVE BUTTON";
//var_dump( Input::get('value'));

/*

NOTE: WHEN i CLICK BUTTON [ Approve Credit ] 
      Reset/Update the payment status from "Success" to "Pending"

SELECT b.id, b.branch_name, b.branch_credits, ba.credits_issued_to_date FROM branch b
INNER JOIN branch_additionals ba ON b.id = ba.branch_id
WHERE b.id = 1

SELECT   b.invoice_no, b.credit_price, b.branch_name, b.branch_credits, b.credit_price, ba.credits_issued_to_date, 
ba.id, ba.address_line1, ba.address_line2, ba.address_line3, ba.address_line4 
FROM branch b
INNER JOIN branch_additionals ba ON b.id = ba.branch_id
WHERE b.id =
*/



$db = DB::getInstance();

$registered_name = '';
$business_email = '';
$physical_address = '';

$branch_id = Input::get('approve_id');
$credit = Input::get('value');  //Drowdown Selected value


/*
$data = $db->query("SELECT b.branch_name, b.branch_credits, ba.credits_issued_to_date, ba.id, b.credit_price 
	FROM branch b 
	INNER JOIN branch_additionals ba ON b.id = ba.branch_id WHERE b.id =" . $branch_id);

*/

$data = $db->query("SELECT b.invoice_no, b.credit_price, b.branch_name, b.branch_credits, b.credit_price, ba.credits_issued_to_date, 
	ba.id, ba.address_line1, ba.address_line2, ba.address_line3, ba.address_line4 
	FROM branch b 
	INNER JOIN branch_additionals ba ON b.id = ba.branch_id 
	WHERE b.id =" . $branch_id);


#UPDATE TWO TABLES [ branc & branch_additionals ]

//var_dump( $data );


$output = '';
$option = '';
if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	$output .= "
	<tr>
	    <td>This client is not found in our clients table records</td>
	</tr>
	";

}else{
   
    

	//b.branch_name, b.branch_credits, ba.credits_issued_to_date, ba.id, 
	foreach( $data->results() as $result ){
		//var_dump( $result->registered_name );
		$result->branch_name;
		$result->branch_credits;
		$result->credits_issued_to_date;
		$result->id;
	
	}


	try{
	#UPDATE THE CREDIT  

			$db->update( 'branch', $branch_id, array(	

				'branch_credits'      	=> $result->branch_credits + $credit,
				'date_modified' 		=> date('Y-m-d')
				

			) );

			#GET THE branch_additionals = id
			$db->update( 'branch_additionals', $result->id, array(	
				'credits_issued_to_date'  	=> $result->credits_issued_to_date + $credit,
				'payment'					=> "Pending"

			) );

			//echo "Credits Approved";

	}catch( Exception $e ){
		die( $e->getMessage() );
	} 


}



#SAVING DATA INTO THE TB INVOICE
/*
TB:branch_invoice 
`id`, `branch_id`, `invoice_no`, `quantity`, `unit_price`, `total_price`, `date_invoiced`

TB: branch_invoice_additionals
`id`, `branch_invoice_id`, `sales_rep`, `invoice_reference`, `recipient_address_line1`, `recipient_address_line2`, `recipient_address_line3`, 
`recipient_address_line4`, `description`, `status`, `due_date`, `updated_at`, `deleted_at`

*/

//echo "branch_id: " . $branch_id . "<br/>"; 

//echo "Invoice No: " . $result->invoice_no . "<br/>";

//echo "quantity: " . $credit . "<br/>";

//echo "Unit Price: " . $result->credit_price . "<br/>";


$total_price = ($credit * $result->credit_price);
//echo "Total Price" . $total_price . "<br/>";

$date_invoiced = date('Y-m-d'); 
//echo "Date Invoice" . $date_invoiced . "<br/>";

#NEXT TABLE
$sales_rep = "A.I.S";
//echo "Sales Rep: " . $sales_rep . "<br/>";

$num_str = sprintf("%06d", mt_rand(1, 999999));
$invoice_reference =  "MG" .  $num_str;
//echo "Invoice Reference: " . $invoice_reference . "<br/>";

/*
`address_line1``address_line2``address_line3``address_line4`
*/
//echo "Recipient_address_line1: " . $result->address_line1 . "<br/>";

//echo "Recipient_address_line2: " . $result->address_line2 . "<br/>";

//echo "Recipient_address_line3: " . $result->address_line3 . "<br/>";

//echo "Recipient_address_line4: " . $result->address_line4 . "<br/>";


$description = "Advanced Intelligence System";

//echo "description: " . $description . "<br/>";

#JUMP STATUS

$time = strtotime( date("Y-m-d") );
//$due_date = date("Y-m-d", strtotime("+1 month", $time));
$due_date = date("Y-m-d", strtotime("+1 week", $time));
//echo "Due Date: " . $due_date . "<br/>";


#WE ARE IN TWO TABLES [ branch_invoice & branch_invoice_additionals ]
try{
	#Create a new user
	//TB:branch_invoice 
	//`id`, `branch_id`, `invoice_no`, `quantity`, `unit_price`, `total_price`, `date_invoiced`

	//SELECT id FROM branch_invoice ORDER BY id DESC LIMIT 1

	//$data_id = $db->query("SELECT id FROM branch_invoice WHERE branch_id = $branch_id ORDER BY id DESC LIMIT 1");

	$data_id = $db->query("SELECT id FROM branch_invoice ORDER BY id DESC LIMIT 1");
	if( !$data_id->count() ){
		    #NO DATA FOUND IN THE DATABASE
		echo "No invoice data found";

	}else{

		 $x = 1;
		foreach( $data_id->results() as $result_inv ){
			$result_inv->id;
		}

	}

	$save = $db->insert( 'branch_invoice', array(	
			
		'id'    		    => ++$result_inv->id,		
		'branch_id'    		=> $branch_id,
		'invoice_no'		=> $result->invoice_no,
		'quantity'	  		=> $credit,
		'unit_price'		=> $result->credit_price,
		'total_price'       => $total_price,
		'date_invoiced' 	=> $date_invoiced
		

	) );


	#branch_invoice_additionals
	
	$save = $db->insert( 'branch_invoice_additionals', array(	
					
		'branch_invoice_id'    	 	=> $result_inv->id,
		'sales_rep'        			=> $sales_rep,
		'invoice_reference'    		=> $invoice_reference,
		'recipient_address_line1'   => $result->address_line1,
		'recipient_address_line2'   => $result->address_line2,
		'recipient_address_line3'   => $result->address_line3,
		'recipient_address_line4'   => $result->address_line4,
		'description'        		=> $description,
		'due_date'        			=> $due_date

		

	) );

	//echo "Credits loaded";
    echo "Credits Approved";
    #NOTE: SEND INVOICE HERE MY BUDDY
	

}catch( Exception $e ){
	die( $e->getMessage() );
} 


?>