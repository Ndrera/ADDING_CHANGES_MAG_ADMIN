<?php
//action.php

require_once 'core/init.php';
//require('fpdf182/fpdf.php');


$output = '';

$id 	    = Input::get('id');      #NOTE:IT'S    credit_id
$date_from  = Input::get('date_from');
$date_to    = Input::get('date_to');

//echo "[BRANCH] HIDDEN ID: " . $id . "   DATE FROM: " . $date_from . "  DATE TO: " . $date_to;



Session::put('credit_id', $id);
Session::put('date_from', $date_from);
Session::put('date_to', $date_to);

//$data = DB::getInstance()->query("SELECT * FROM invoices WHERE credit_id =" . $id );
//$data = DB::getInstance()->query("SELECT * FROM `invoices` WHERE credit_id = 1 AND (created_at BETWEEN '2020-11-09' AND '2020-11-09')");

#WILL SELECT FROM TWO TABLES [ `branch_invoice` & `branch_invoice_additionals` ] use date_invoiced
/*
SELECT * FROM branch_invoice bi
INNER JOIN branch_invoice_additionals bia ON bi.id = bia.branch_invoice_id
WHERE (date_invoiced BETWEEN '2020-11-11' AND '2020-11-11') AND bi.branch_id = 1

SELECT * FROM branch_invoice bi
INNER JOIN branch_invoice_additionals bia ON bi.id = bia.branch_invoice_id
WHERE (date_invoiced BETWEEN '$date_from' AND '$date_to') AND bi.branch_id = $id
***/

//$data = DB::getInstance()->query("SELECT * FROM invoices WHERE (created_at BETWEEN '$date_from' AND '$date_to') AND credit_id = $id ");



$data = DB::getInstance()->query("SELECT * FROM branch_invoice bi 
	INNER JOIN branch_invoice_additionals bia ON bi.id = bia.branch_invoice_id 
	WHERE (bi.date_invoiced BETWEEN '$date_from' AND '$date_to') AND bi.branch_id = $id");



if( !$data->count() ){
   
	echo "0";

}else{

	echo "1";

}


echo $output;





?> 