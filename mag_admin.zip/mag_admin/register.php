<?php
require_once 'core/init.php';

if( Input::exists() ){
	if( Token::check( Input::get('token') ) ){

	   #PUT A SESSION IN THE CODE
	   #


		$output = "";

		$validate = new Validate();
		$validate = $validate->check( $_POST, array(
				
				/*
				'company_name' => array(  

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),'company_code' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 100
					
				),
				*/

				'username' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50

					//'unique'   => 'users'
					
				),
				'email' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 60,
					'valid_email'  => true,
					'unique'   => 'users'

					//'max'	   => 50,
					//'unique'   => 'users'
					
				),
				'password' => array(

					'required' => true,
					'min'	   => 6

				),
				'name' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'password_again' => array(

					'required' => true,
					'matches'  => 'password'

				)
				

		) );

	
		if( $validate->passed() ){
			 #Add a user

			$user = new User();

			//$salt = Hash::salt(32);
			$salt = Hash::salt();  #CHECK FOR MCRYPT REPLACEMENT

			//var_dump( $salt  ); die;

			try{
				#Create a new user
				
				$user->create( array(	
					/*
					'company_name' 	=> Input::get('company_name'),
					'company_code' 	=> Input::get('company_code'),
					*/

					'username'    	=> Input::get('username'),
					'email'		  	=> Input::get('email'),
					'password'	  	=> Hash::make( Input::get('password'), $salt ),
					'salt'		 	=> $salt,
					'name'        	=> Input::get('name'),
					'created_at' 	=> date('Y-m-d H:i:s'),
					'group'		 	=> 1
					

				) );

				Session::flash( 'output', "<div class='alert alert-success'>New user has been successfully added!</div>" );
				

			}catch( Exception $e ){
				die( $e->getMessage() );
			} 

		

		}else{

			#Output errorrs
			foreach( $validate->errors() as $error ){
				//echo $error . "<br/>";
				$output .= $error . '.<br/>';
				Session::put( 'output', "<div class='alert alert-danger'>" . $output . "</div>" );
			}
		

		}



	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>

	<!-- # NAV -->
	<nav class="nav navbar-inverse">
		<div class="container">
			
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">Advanced Intelligence System</a>
			</div>

			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav" id="_links">
		
					<li class=""><a href="index.php">Home</a></li>
					<li class=""><a href="register.php">Add User</a></li>
					<li class=""><a href="add_client.php">Add Client</a></li>
					<li class=""><a href="billing.php">Billing</a></li>
					<li class=""><a href="logout.php">Logout</a></li>
					<!-- 
					<li id="_li"></li>
					-->

				</ul>
			</div>

		</div>
	</nav>


	<!-- # CONTAINER -->
	<div class="container container-bg">
		<div class="row">

			<div class="col-md-12">
			    <p>
					<div class="well border-color">
					<!-- # WELL <div class="well"> -->

						 <div id="results" class="text-center">
					 		 <?php
					 		   if( Session::exists('output') ){
					 		   	   echo  Session::flash('output');

								}
					 		 ?>
					   	 </div>

						 <!-- ADD THE TABLE OUTSIDE -->
						 <table class="table">
						 		<thead class="thead-dark">
						 			<tr>
						 			    <!-- # NOTE MINIMIZE THIS AS SCREEN DECREASES -->
						 				<th colspan="2" ><h3>Add New User:</h3></th>
						 			</tr>
						 		</thead>

						 		<!--
						 		<tbody>

						 			<tr>
						 				<td colspan="2">
						 				
						 					<button type="reset" value="Reset" class="btn btn-warning btn-block">Clear Form</button>
						 				</td>
						 			</tr>	


						 		</tbody>
						 		-->

						</table>



						 <ul class="list-group">
					   	 <li class="list-group-item">


					   	 <!-- #ADD IMAGE HERE-->
					   	  <img class="img-fluid img-rounded" src="images/bi2.png" style="width: 100%;height: 95px;">
					   	


						<!-- <hr/> -->


					   	
					   	

						 <form action="" method="post" id="register_form">

						 	<table class="table">

						 		<!--
						 		<thead class="thead-dark">
						 			<tr>
						 				<th colspan="2" ><h3>Add New User:</h3></th>
						 			</tr>
						 		</thead>
						 		-->
						 		<thead class="thead-dark">
						 			<tr>
						 				<th colspan="2" ></th>
						 			</tr>
						 		</thead>

						 		<tbody>
						 			<tr>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Username:</label>
							   	  	 			<input type="text" name="username" id="username" value="<?php echo escape( Input::get('username') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Email:</label>
							   	  	 			<input type="text" name="email" id="email"  value="<?php echo escape( Input::get('email') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>

						 			<tr>
						 				<td colspan="2">
						 					<div class="form-group">
							   	  	 			<label>Name:</label>
							   	  	 			<input type="text" name="name" id="name"  value="<?php echo escape( Input::get('name') ); ?>" class="form-control border-color">
							   	  	 		</div>
						 				</td>
						 			</tr>

						 			<tr>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Password:</label>
							   	  	 			<input type="password" name="password" id="password" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 				<td colspan="2">
						 					<div class="form-group">
							   	  	 			<label>Re-Enter Password:</label>
							   	  	 			<input type="password" name="password_again" id="password_again" class="form-control border-color">
							   	  	 		</div>
						 				</td>

						 			</tr>

						 			<tr>
							   	  	 	<td colspan="2">
							   	  	 		<div class="form-group">
							   	  	 		    <input type="hidden" name="token" value="<?php echo Token::generate(); ?>">
							   	  	 			<input type="hidden" name="action" id="action" value="" >
							   	  	 			<input type="submit" name="register" id="register" value="Add User" class="btn btn-primary btn-block">
							   	  	 		</div>
							   	  	 	</td>
							   	  	 </tr>

						 		</tbody>
						 	</table>
					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>
			</div>			

		</div>
	</div>

	<!-- # FOOTER -->
	
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S</p>
	</footer>

</body>
</html>

<!-- Search for People -->
<script type="text/javascript">
$(document).ready( function(){
        
	//ADD HERE, MAYBE IF I CHOOSE TO VALIDATE THIS SIDE


} );

</script>