<?php
require_once 'core/init.php';

const _INSERT_VALUE = "insert";

$user = new User();
 
if( Input::get('action') == 'insert' ){
 
		$validate = new Validate();
		$validate = $validate->check( $_POST, array(
				
				'name' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'email' => array(

					'required' => true,
					'min' 	   => 5,
					'max'	   => 50,
					'valid_email'	   => true,
					'unique'   => 'users'
					
				),
				'phone_number' => array(

					'required' => true,
					'min' 	   => 2,
					'valid'	   => true

				)


		) );

		
		if( $validate->passed() ){
			 
			#SAVE CONTACT DATA
			try{

				#Sanitize the phone number
				$filer_number = filter_var( Input::get('phone_number'), FILTER_SANITIZE_NUMBER_INT);

				if( strlen($filer_number) > 10 ){
					$substr = substr($filer_number , 3);
					$filer_number = 0 . $substr;
				}

				#Create contact
				$user->create( array(

					'name'        		=> Input::get('name'),
					'email'		  		=> Input::get('email'),
					'phone_number' 		=> $filer_number,

					'date_of_birth'		=> Input::get('date_of_birth'),
					'gender'			=> Input::get('gender'),
					'id_number'			=> Input::get('id_number'),

					'car_make'			=> Input::get('car_make'),
					'car_color'			=> Input::get('car_color'),
					'car_registration'	=> Input::get('car_registration')
				

				) );				
				
				echo "<div class='alert alert-success'>Thank you, you have submitted your contact form.</div>";
				

			}catch( Exception $e ){
				die( $e->getMessage() );
			} 

		

		}else{

			#Output errorrs
			foreach( $validate->errors() as $error ){
				echo $error . "<br/>";
			}
		}

}


#ADD A NEW USER
if( Input::get('action') == 'add_user' ){
	
	//return '1';
	//echo 1;
	//echo 2;


	echo Input::get('company_name') . '<br/>';
	echo Input::get('username') . '<br/>';
    echo Input::get('email') . '<br/>';
    echo Input::get('name') . '<br/>';
    echo Input::get('password') . '<br/>';


    /*
	#TO PART WORKS FINE PLAYER
	$validate = new Validate();
		$validate = $validate->check( $_POST, array(
				
				'company_name' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'username' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50

					//'unique'   => 'users'
					
				),
				'email' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 60,
					'valid_email'  => true,
					'unique'   => 'users'

					//'max'	   => 50,
					//'unique'   => 'users'
					
				),
				'password' => array(

					'required' => true,
					'min'	   => 6

				),
				'name' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'password_again' => array(

					'required' => true,
					'matches'  => 'password'

				)
				

		) );

	
		if( $validate->passed() ){
			 #Add a user

			$salt = Hash::salt(32);

			try{
				#Create a new user
				
				$user->create( array(

					
					'company_name' 	=> Input::get('company_name'),
					'username'    	=> Input::get('username'),
					'email'		  	=> Input::get('email'),
					'password'	  	=> Hash::make( Input::get('password'), $salt ),
					'salt'		 	=> $salt,
					'name'        	=> Input::get('name'),
					'created_at' 	=> date('Y-m-d H:i:s'),
					'group'		 	=> 1
					

				) );

				//var_dump( $user ); die;
				

				#FLASH - a session message
				Session::flash( 'home', 'The new user has been successfully added!' );
				//echo true;
				echo 1;


			}catch( Exception $e ){
				die( $e->getMessage() );
			} 

		

		}else{

			#Output errorrs
			//print_r( $validate->errors() );
			//<div class='alert alert-danger'>
			//$output = "";
			//$output .= "<div class='alert alert-danger'>";
			foreach( $validate->errors() as $error ){
				echo $error . "<br/>";
				//$output .= $error . '.<br/>';
			}
			//echo $output .= "</div>";

		}
	
	*/

}

