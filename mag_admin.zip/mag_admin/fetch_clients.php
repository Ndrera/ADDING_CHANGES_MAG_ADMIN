<?php
require_once 'core/init.php';


#NOTE: ITS clients TB
/*

SELECT b.id, b.branch_name, b.branch_code, b.branch_contact, b.branch_email, b.date_modified, ba.suspend_status  FROM `branch` b
INNER JOIN `branch_additionals` ba ON b.id = ba.branch_id;


*/

//$data = DB::getInstance()->query("SELECT * FROM clients");

$data = DB::getInstance()->query("SELECT b.id, b.branch_name, b.branch_code, b.branch_credits, b.branch_contact, b.branch_email, b.date_modified, ba.suspend_status 
	FROM branch b 
	INNER JOIN branch_additionals ba ON b.id = ba.branch_id");


//var_dump( $data );


$output = '';
$option = '';
$active_button = '';
if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	$output .= "
	<tr>
	    <td>No table records are found on this table.</td>
	</tr>
	";

}else{

	#[  b.id, b.branch_name, b.branch_code, b.branch_contact, b.branch_email, b.date_modified, ba.suspend_status ]

	$x = 1;
	foreach( $data->results() as $result ){



		if( $result->suspend_status == 1 ){
	  		$active_button = '<button type="button" name="suspend" id="' . $result->id . '" class="btn btn-success btn-block suspend">Un-Suspend</button>';
	  	}else{
	  		$active_button = '<button type="button" name="suspend" id="' . $result->id . '" class="btn btn-danger btn-block suspend">Suspend</button>';
	  	}
         
		$output .= '
		    <tr>
		      <th scope="row">'. $x .'</th>
		      <th scope="row">' . $result->branch_name . '</th>
		      <td>' . $result->branch_code . '</th>
		      <td><input type="text" name="branch_credits" id="branch_credits" value=" ' . $result->branch_credits . ' " class="form-control border-color" disabled></td>
		      <td>' . $result->branch_email . '</th>
		      <td>' . $result->branch_contact . '</th>
		      <td>' . $result->date_modified . '</th>
		      <td>' . $active_button  . '</td>
		      <td><button type="button" name="edit" id="' . $result->id . '" class="btn btn-primary btn-block edit">Edit</button></td>
		    </tr>';

		$output .= $x < count( $data->results() ) ? "<hr/>" : "";
		$x++;

		
	}



}


echo $output;



?>