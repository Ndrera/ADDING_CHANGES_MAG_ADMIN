<?php

/*call the FPDF library*/
require_once 'core/init.php';
require('fpdf182/fpdf.php');

#NOTE: MAYBE i can pass the value in form fields [ $('id').value() ] or aa [ invoice.php?id=1 ] 
//echo "WE ARE IN THE INVOICE FILE";

$id = Input::get('id');
$date_from = Input::get('from');
$date_to = Input::get('to');
$company_name = '';
$subtotal = 0;
$vat_total = 0;
$total_amount = 0;

$data_name = DB::getInstance()->query("SELECT registered_name FROM branch_additionals WHERE branch_id = $id");
foreach( $data_name->results() as $name ){
	$company_name = $name->registered_name;
}


$data = DB::getInstance()->query("SELECT * FROM branch_invoice bi 
	INNER JOIN branch_invoice_additionals bia ON bi.id = bia.branch_invoice_id 
	WHERE (bi.date_invoiced BETWEEN '$date_from' AND '$date_to') AND bi.branch_id = $id");


//var_dump( $data ); die;

if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
   

	echo "No invoice data found";

}else{

    //echo "Yes We found the data";
	 //$x = 1;


	

     #GET NAME
	/*
	SELECT `registered_name` 
	FROM `branch_additionals`
	WHERE `branch_id` = 1
	*/
	


	foreach( $data->results() as $result ){  



		/*
		TB: branch_invoice
		`id`, `branch_id`, `invoice_no`, `quantity`, `unit_price`, `total_price`, `date_invoiced`


		TB: branch_invoice_additionals
		`id`, `branch_invoice_id`, `sales_rep`, `invoice_reference`, `recipient_address_line1`, `recipient_address_line2`, `recipient_address_line3`, 
		`recipient_address_line4`, `description`, `status`, `due_date`, `updated_at`, `deleted_at`
		*/

		#INVOICE
		//echo $result->invoice_no;
        //var_dump( $result );

		/*A4 width : 219mm*/

		$pdf = new FPDF('P','mm','A4');

		$pdf->AddPage();
		/*output the result*/

		/*set font to arial, bold, 14pt*/
		$pdf->SetFont('Arial','B',20);

		/*Cell(width , height , text , border , end line , [align] )*/

		#LOGO
		/*
		// Logo
    $this->Image('logo.png',10,6,30);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(30,10,'Title',1,0,'C');
    // Line break
    $this->Ln(20);
    */

    	//$pdf->Image('images/ict_logo.png',10,6,40);
    	


		#HEAGING [ INVOICE ]
		#BLOCK 1
		/*
		$pdf->Cell(71 ,10,'',0,0);
		$pdf->Cell(59 ,5,'INVOICE',0,0);
		$pdf->Cell(59 ,10,'',0,1);  */

		$pdf->Cell(71 ,10, $pdf->Image('images/ict_logo.png',6,6,49),0,0);
		$pdf->Cell(59 ,5,'',0,0);
		$pdf->Cell(59 ,10,'TAX INVOICE',0,1);
		$pdf->Ln(24);

		#SENDER'S ADDRESS AND DETAILS [ e.p Platinum I.C.T ]
		#BLOCK 2
		/*
		$pdf->SetFont('Arial','B',15);
		$pdf->Cell(71 ,5,'Invoice From:',0,0);
		$pdf->Cell(59 ,5,'',0,0);
		$pdf->Cell(59 ,5,'Invoice Details:',0,1);
		*/

		#$pdf->SetFont('Arial','',10);
		$pdf->SetFont('Arial','B',10);

		#NOTE: IT JUMPS FROM LINE TO LINE
		#NOTE: WHERE YOU WANT TO OMMITE DATA LEAVE BLANK [e.g ,'']
		$pdf->Cell(130 ,5,'',0,0);    //ADDIND SPACE
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'Platinum ICT (Pty) LTD',0,0);  
		$pdf->Cell(25 ,5,'Invoice No:',0,0);
		$pdf->Cell(34 ,5, $result->invoice_reference,0,1);

		$pdf->Cell(130 ,5,'VAT No: 4380274177',0,0);
		$pdf->Cell(25 ,5,'Invoice Date:',0,0);
		$pdf->Cell(34 ,5, $result->date_invoiced,0,1);
		 
		 /*
	     $time = strtotime("2010.12.11");
		 $final = date("Y-m-d", strtotime("+1 month", $time));

		 $time = strtotime( $result->created_at );
		 $final = date("Y-m-d", strtotime("+1 month", $time));

		 */

		$time = strtotime( $result->date_invoiced );
		#$final = date("Y-m-d", strtotime("+1 month", $time));
		$final = date("Y-m-d", strtotime("+1 week", $time));

		$pdf->Cell(130 ,5,'Reg: 2014/281031/07',0,0);
		$pdf->Cell(25 ,5,'Due Date:',0,0);
		$pdf->Cell(34 ,5,$final,0,1);

		$pdf->Cell(130 ,5,'Unit 6b Monpark Center',0,0);
		$pdf->Cell(25 ,5,'Sales Rep:',0,0);
		$pdf->Cell(34 ,5,$result->sales_rep,0,1);

		$pdf->Cell(130 ,5,'76 Skilpad Street',0,0);
		$pdf->Cell(25 ,5,'Print Date:',0,0);
		$pdf->Cell(34 ,5,date("Y-m-d"),0,1);

		$pdf->Cell(130 ,5,'Monument Park, Pretoria',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'0181',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);


		#BLOCK 3
		$pdf->SetFont('Arial','B',15);
		$pdf->Cell(130 ,5,'Invoice To:',0,0);
		$pdf->Cell(59 ,5,'',0,0);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(189 ,10,'',0,1);


		#HERE I AM GOING TO PUT IN THE INVOICE TO DETAILS
		//$pdf->Cell(130 ,5,$name->registered_name,0,0);
		$pdf->Cell(130 ,5,$company_name,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line1,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line2,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line3,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$result->recipient_address_line4,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		#BLOCK 4
		#$pdf->Cell(50 ,10,'',0,1);


		$pdf->SetFont('Arial','B',10);
		/*Heading Of the table*/

		/*
		$pdf=new FPDF();
$pdf->AddPage();

$pdf->SetFont('Times','I',16);

$pdf->cell(100,10,"This is a cell without background fill",1,1,'C');
$pdf->ln();
$pdf->Cell(100,10,'This is a cell with background fill',1,1,'',true);
$pdf->SetFillColor(976,245,458);
$pdf->ln();
$pdf->cell(100,10,"This is a cell with background fill",1,1,'C',true);


$pdf->SetFillColor(976,245,458);
$pdf->ln();
$pdf->cell(100,10,"This is a cell with background fill",1,1,'C',true);

SetDrawColor(0,80,180);
		*/

		//$pdf->SetFillColor(200,220,255);
		//$pdf->SetDrawColor(194, 193, 190);
		$pdf->SetDrawColor(194, 193, 190);
		$pdf->SetFillColor(194, 193, 190);
	    
		$pdf->Cell(108 ,6,'Description',0,0,'L', true);
		$pdf->Cell(20 ,6,'Quantity',0,0,'L', true);
		$pdf->Cell(25 ,6,'Unit Price',0,0,'L', true);
		
		$pdf->Cell(35 ,6,'Total Price',0,1,'L', true);/*end of line*/
		/*Heading Of the table end*/
		$pdf->SetFont('Arial','',10);
		    //for ($i = 1; $i <= count( $data->results() ); $i++) {
		    //for ($i = 1; $i <= count( $data->results()  ); $i++) {
			foreach( $data->results() as $res ){
				//$pdf->Cell(10 ,6,$i,1,0);
				//$pdf->Cell(10 ,6,$x,1,0);
				//$pdf->Cell(10 ,6,'',1,0);
				#[ C = Center ] [ R = Right ] [ L = Left ]
				$pdf->Cell(108 ,6, $res->description,0,0,'L');
				$pdf->Cell(20 ,6,$res->quantity,0,0,'L');
				
				$pdf->Cell(25 ,6, 'R'. $res->unit_price,0,0,'L');
				$pdf->Cell(35 ,6, 'R'. $res->total_price,0,1,'l');

				$subtotal += $res->total_price;

				$vat_total = ( $subtotal * 0.15 );

				$total_amount = $subtotal + $vat_total ;

				/*

				$pdf->Cell(80 ,6, $res->description,1,0);
				$pdf->Cell(23 ,6,$res->quantity,1,0,'R');
				
				$pdf->Cell(40 ,6, 'R'. $res->unit_price,1,0,'R');
				$pdf->Cell(45 ,6, 'R'. $res->total_price,1,1,'R');

				*/

			}
			

	

		#BLOCK 5    [ FOR TOTAL ]
	
		/*
		$pdf->Cell(50 ,10,'',0,1);
	    $pdf->Cell(50 ,10,'',0,1);
	    */

	    //$pdf->SetFillColor(194, 193, 190);

	    /*# SET FOOTER

	    // Position at 1.5 cm from bottom
	    $this->SetY(-15);
	    // Arial italic 8
	    $this->SetFont('Arial','I',8);
	    // Page number
	    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
	     
	    */

	    $pdf->SetY(-60);

		$pdf->SetFont('Arial','',10);
		/*Heading Of the table*/
		//$pdf->Cell(10 ,6,'No',1,0,'C');  
		$pdf->Cell(128 ,6,'Platinum Internet Communication and Telecommunications',1,0,'L', true);
		//$pdf->Cell(20 ,6,'Quantity',1,0,'L');
		$pdf->Cell(25 ,6,'SUBTOTAL',0,0,'L', true);
		$pdf->Cell(35 ,6, "R " . number_format($subtotal, 2) ,0,1,'L', true);/*end of line*/


		$pdf->Cell(128 ,6,'FNB Business Cheque Account',1,0,'L' , true);
		$pdf->Cell(25 ,6,'VAT@15%',0,0,'L');
		$pdf->Cell(35 ,6,"R " . number_format($vat_total, 2),0,1,'L');/*end of line*/

		$pdf->Cell(128 ,6,'Branch Code 250655',1,0,'L', true);
		$pdf->Cell(25 ,6,'TOTAL',0,0,'L', true);
		//$pdf->Cell(35 ,6,"R " . $total_amount ,0,1,'L', true);/*end of line*/

		$pdf->Cell(35 ,6,"R " .  number_format($total_amount,2) ,0,1,'L', true);/*end of line*/


		$pdf->Cell(128 ,6,'Account No. 62517320727',1,0,'L', true);
		$pdf->Cell(25 ,6,'',0,0,'L');
		$pdf->Cell(35 ,6,'',0,1,'L');/*end of line*/

		$pdf->Cell(128 ,6,'',1,0,'L', true);
		$pdf->Cell(25 ,6,'',0,0,'L');
		$pdf->Cell(35 ,6,'',0,1,'L');/*end of line*/

		$pdf->Cell(128 ,6,'Please reference your invoice number when processing payment',1,0,'L', true);
		$pdf->Cell(25 ,6,'',0,0,'L');
		$pdf->Cell(35 ,6,'',0,1,'L');/*end of line*/


		//$pdf->Output();
		//$pdf->Output("I", "AISI100756.pdf"); $result->invoice_reference
		$pdf->Output("I", $result->invoice_reference . ".pdf"); 






	}


} 




?>
