<?php
require_once 'core/init.php';


/*
 "SELECT * FROM invoices WHERE id =  Input::get('action')  
  AND (created_at BETWEEN $from_date AND $date_to)"
*/

echo Input::get('my_id');
//$data = DB::getInstance()->query("SELECT * FROM invoices ");



?>