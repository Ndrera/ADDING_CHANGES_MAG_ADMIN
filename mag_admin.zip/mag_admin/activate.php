<?php
require_once 'core/init.php';

/*
- I will get the details from db
- Then check the statuts

FOR "Active" i will decativate
FOR "Inactive" i will activate 


*/

//echo "ACTIVE STATUS";

//echo Input::get('activate_id');
$db = DB::getInstance();

$id = Input::get('activate_id');


//$data = $db->query("SELECT credit_status FROM branch_additionals WHERE branch_id = $id");
$data = $db->query("SELECT credit_status, id FROM branch_additionals WHERE branch_id = $id");

if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	echo "No credit data found";

}else{

	 foreach( $data->results() as $result ){
	 	$result->id;

	 	if( $result->credit_status == "Active" ){
	 		$status = "Inactive";

	 	}else{
	 		$status = "Active";
	 	}


	 }

	// var_dump($statuts);
	// echo $status;
	 


	 
	 #UPDATE THE STATUS
	 try{
	       #GET THE [ TB: branch_additionals ] actual id

			//$db->update( 'branch_additionals', $id, array(

			$db->update( 'branch_additionals', $result->id, array(	

				'credit_status'      	=> $status
				
				
			) );

			echo "You have set the credit to " . $status;

	 }catch( Exception $e ){
		die( $e->getMessage() );
	 } 



}
	
   


?>