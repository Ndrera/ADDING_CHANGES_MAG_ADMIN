<?php
require_once 'core/init.php';


//echo "WE ARE SUSPENDING PPL";
//echo Input::get('suspend_id');


$db = DB::getInstance();

$id = Input::get('suspend_id');


/*
SELECT b.branch_name, ba.suspend_status  FROM `branch` b
INNER JOIN `branch_additionals` ba ON b.id = ba.branch_id
WHERE b.id = $id;

*/

//SELECT STATUS, updated_at FROM `clients` WHERE id = 1
//$data = $db->query("SELECT c.status, updated_at FROM clients c WHERE id = $id");

$data = $db->query("SELECT b.branch_name, ba.suspend_status, ba.id 
	FROM branch b 
	INNER JOIN branch_additionals ba ON b.id = ba.branch_id 
	WHERE b.id = $id");

//var_dump($data );



if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	echo "No data found in the tables";

}else{

	 foreach( $data->results() as $result ){
	 	
	 	if( $result->suspend_status == 1 ){
	 		$status = 0;

	 	}else{
	 		$status = 1;
	 	}


	 }

	// var_dump($statuts);
	// echo $status;
	 


	 
	 #UPDATE THE STATUS
	 try{
	 #UPDATE THE CREDIT  

			$db->update( 'branch_additionals', $result->id, array(	

				'suspend_status'      	=> $status
				

			) );

			echo "You have updated the status";

	 }catch( Exception $e ){
		die( $e->getMessage() );
	 } 



}





?>