<?php
require_once 'core/init.php';


#FETCH ALL THE DATA FROM DB
/*
SELECT b.id, b.branch_name, b.branch_credits, ba.payment, ba.credit_status, b.date_modified FROM `branch` b
INNER JOIN `branch_additionals` ba ON ba.branch_id = b.id;
*/

//$data = DB::getInstance()->query("SELECT * FROM credits");

$data = DB::getInstance()->query("SELECT b.id, b.branch_name, b.branch_credits, ba.payment, ba.credit_status, b.date_modified 
	FROM branch b 
	INNER JOIN branch_additionals ba ON ba.branch_id = b.id");


//var_dump( $data );

$output = '';
$option = '';
$active_button = '';
if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	$output .= "
	<tr>
	    <td>No table records are found on this table.</td>
	</tr>
	";

}else{

	$x = 1;
	foreach( $data->results() as $result ){


	  	if( $result->credit_status == "Active" ){
	  		$active_button = '<button type="button" name="activate" id="' . $result->id . '" class="btn btn-warning btn-block activate">De-Activate</button>';
	  	}else{
	  		$active_button = '<button type="button" name="activate" id="' . $result->id . '" class="btn btn-primary btn-block activate">Activate</button>';
	  	}
	   

        
		$output .= '
		    <tr>
		      <th scope="row">'. $x .'</th>
		      <th scope="row">' . $result->branch_name . '</th>
		      <td><input type="text" name="branch_credits" id="branch_credits" value=" ' . $result->branch_credits . ' " class="form-control border-color" disabled></td>
		      <td><input type="text" name="loaded_credits" id="loaded_credits" value=" ' . $result->branch_credits . ' " class="form-control border-color"></td>
		      <td><button type="button" name="approve" id="' . $result->id . '" class="btn btn-success btn-block approve">Approve Credit</button></td>
		      <td><button type="button" name="confirm" id="' . $result->id . '" class="btn btn-info btn-block confirm">Confirm</button></td>
		      <td>' . $result->payment . '</td>
		      <td>' . $active_button . '</td>
		      <td>' . $result->credit_status . '</td>
		      <td>' . $result->date_modified . '</td>
		      <td><button type="button" name="invoice" id="' . $result->id . '" class="btn btn-danger btn-block invoice">Invoice</button></td>
		      <td><button type="button" name="statement" id="' . $result->id . '" class="btn btn-primary btn-block statement">Statement</button></td>
		    </tr>
		    ';


		$output .= $x < count( $data->results() ) ? "<hr/>" : "";
		$x++;

		
	}

}


echo $output;



?>