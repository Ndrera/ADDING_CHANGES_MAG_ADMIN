<?php
require_once 'core/init.php';

$user = new User();
if( !$user->isLoggedIn() ){
 	Redirect::to('login.php');
}



?>
<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>

	<!-- # NAV -->
	<nav class="nav navbar-inverse">
		<div class="container">
			
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">Advanced Intelligence System</a>
			</div>

			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav" id="_links">
		
					<li class=""><a href="index.php">Home</a></li>
					<li class=""><a href="register.php">Add User</a></li>
					<li class=""><a href="add_client.php">Add Client</a></li>
					<li class=""><a href="billing.php">Billing</a></li>
					<li class=""><a href="logout.php">logout</a></li>
					<!-- 
					<li id="_li"></li>
					-->



				</ul>
			</div>

		</div>
	</nav>


	<!-- # CONTAINER -->
	<div class="container container-bg">
		<div class="row">

			<div class="col-md-12">
			    <p>
					<div class="well border-color">
					<!-- # WELL <div class="well"> -->

						  <table class="table">
						 		<thead class="thead-dark">
						 			<tr>
						 				<th colspan="2" ><h3>Billing:</h3></th>
						 			</tr>
						 		</thead>

						 		<!--
						 		<tbody>

						 		
									<tr>
						 				<td>
						 					<button class="btn btn-success btn-block">Billing</button>
						 				</td>

						 				<td>
						 					<button class="btn btn-info btn-block">Invoice History</button>
						 				</td>
						 			</tr>

						 			<tr>
						 				<td colspan="2">
						 					<button class="btn btn-warning btn-block">Statement</button>
						 				</td>
						 			</tr>	
						 			


						 		</tbody>
						 		-->
						 </table>

						 <ul class="list-group">
					   	 <li class="list-group-item">

					   	  <img class="img-fluid img-rounded" src="images/bi2.png" style="width: 100%;height: 95px;">
					   	


						 <hr/>


						 <!-- #TABLE 2 -->

					   	 <div id="results" class="text-center">
					 		
					   	 </div>
					   	
					   	 <!-- #LOAD CREDIT DROPBOX -->
					   	<div class="form-group">
		   	  	 			<!-- <label>Select Credits:</label> -->
		   	  	 			<label>SELECT CREDITS:</label>

		   	  	 			 <select name="load_credit" id="load_credit" class="form-control" style="border:2px solid #FF0000;">
		   	  	 			 	<option value="0">Select Credits</option>
							  	<option value="10">10</option>
							  	<option value="20">20</option>
							  	<option value="30">30</option>
							  	<option value="40">40</option>
							  	<option value="50">50</option>
							  	<option value="60">60</option>
							  	<option value="70">70</option>
							  	<option value="80">80</option>
							  	<option value="90">90</option>
							  	<option value="100">100</option>
								<option value="150">150</option>
								<option value="200">200</option>							  	
							 </select>

						</div>


						 <form action="" method="post" id="credit_form">
						 							 
						 	<div class="table-responsive">
						 	<table class="table">
						 	
								<thead class="black white-text"> 
						 			<tr>
						 	
						 				<th class="success" scope="col">NO</th>
								        <th class="success" scope="col">Client Name</th>
								        <th class="success" scope="col">Available Credit</th>

								        <!--
								        <th class="success" scope="col">Load Credit</th>
								    	-->
								    	<th class="success" scope="col">Approved Credits</th>
								        <th class="success" scope="col">Approve</th>
								        <th class="success" scope="col">Confirm Payment</th>
								        <th class="success" scope="col">Payment</th>
								        <th class="success" scope="col">Auth</th>
								        <th class="success" scope="col">Status</th>
								        <th class="success" scope="col">Date Modified</th>
								        <th class="success" scope="col">Invoice</th>
								        <th class="success" scope="col">Statement</th>

						 			</tr>
						 		</thead>

						 		<!--
						 		<tbody id="bills_output"><?php //echo $output; ?></tbody>
						 	    -->
						 		<tbody id="bills_output"></tbody>

						 		<tbody id="invoice_output"></tbody>
						 		

						 	</table>
						 </div>
						   

					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>
			</div>			

		</div>
	</div>

	<!-- # FOOTER -->
	
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S</p>
	</footer>

</body>
</html>

<!-- #MODAL FOR INVOICE AND STATEMENT 
<div id="apicrudModal" class="modal fade" role="dialog">
-->
<div id="billModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			
			<form method="post" id="invoice_form">
				
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Pull Invoice</h4>
				</div>
				<!-- Modal Body-->
				<div class="modal-body">

					<div class="form-group">
						<label>Date From:</label>
						<input type="date" name="date_from" id="date_from" class="form-control" required />
					</div>
					<div class="form-group">
						<label>Date To:</label>
						<input type="date" name="date_to" id="date_to" class="form-control" required />
					</div>

				</div>
				<!-- Modal Footer -->
				<div class="modal-footer">
					<input type="hidden" name="hidden_id" id="hidden_id" />

					<input type="hidden" name="action" id="action" value="insert" />

					<!-- <input type="submit" name="button_action" id="button_action" class="btn btn-info" value="Print" /> --> 
					<!--<input type="submit" name="button_action" id="button_action" class="btn btn-info print_invoice" value="Print" />
					-->
					<input type="submit" name="print_invoice" id="print_invoice" class="btn btn-info" value="Print" />


					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

				</div>

			</form>

		</div>
	</div>
</div>

<!-- #MODAL STATEMENT -->
<div id="statementModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			
			<form method="post" id="statement_form">
				
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Pull Statement</h4>
				</div>
				<!-- Modal Body-->
				<div class="modal-body">


					<div class="form-group">
						<label>Date From:</label>
						<input type="date" name="statement_date_from" id="statement_date_from" class="form-control" required />
					</div>
					<div class="form-group">
						<label>Date To:</label>
						<input type="date" name="statement_date_to" id="statement_date_to" class="form-control" required />
					</div>

				</div>
				<!-- Modal Footer -->
				<div class="modal-footer">
					<input type="hidden" name="statement_hidden_id" id="statement_hidden_id" />

					<input type="hidden" name="action" id="action" value="insert" />

					<!-- <input type="submit" name="button_action" id="button_action" class="btn btn-info" value="Print" /> --> 
					<!--<input type="submit" name="button_action" id="button_action" class="btn btn-info print_invoice" value="Print" />
					-->
					<input type="submit" name="print_statement" id="print_statement" class="btn btn-info" value="Print" />


					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

				</div>

			</form>

		</div>
	</div>
</div>



<!-- Search for People -->
<script type="text/javascript">
$(document).ready( function(){

	fetch_data();

	function fetch_data(){

		$.ajax({
			url:"fetch.php",
			success:function(data){

				//$('tbody').html(data);
				$('#bills_output').html(data);
			}
		})
	}

	
	//INVOICE   
	$(document).on('click', '.invoice', function(){


		var id = $(this).attr('id');
		sessionStorage.setItem("_id_now", id);

		$('#hidden_id').val(id);
		//alert( $('#hidden_id').val(id) );
		//$('#apicrudModal').modal('show');
		$('#billModal').modal('show');   //DATES FORM
	    
		
	    /***
		sessionStorage.SessionName = "SessionData" ,
		sessionStorage.getItem("SessionName") and
		sessionStorage.setItem("SessionName","SessionData");
		***/

	});


	$('#invoice_form').on('submit', function(event){
		event.preventDefault();
			//$('#billModal').modal('hide');
			//alert("Submitted: " + id + " Date From: " + date_from);
			 
			//alert("HIDDEN ID ATTR: " + $('#hidden_id').val() + " SESSION SAVED ID: " + sessionStorage.getItem("_id_now"));

			
			var date_from = $('#date_from').val();
			var date_to = $('#date_to').val();

			//var my_id = sessionStorage.getItem("_id_now");
			var my_id = $('#hidden_id').val();
			//alert( my_id);
			//alert( my_id);

			//alert("HIDDEN ID ATTR: " + my_id + " DATE FROM: " + date_from +  "  DATE TO: " + date_to );


			//var form_data = $(this).serialize();
			$.ajax({
				url:"action.php",
				method:"POST",
				//data:form_data,
				data:{id:my_id, date_from:date_from, date_to:date_to },
				success:function(data){

					//alert(data);
					//$('#invoice_output').hide();
					//$('#bills_output').hide(); 
					
					//alert("HIDDEN ID ATTR: " + my_id + " DATE FROM: " + date_from +  "  DATE TO: " + date_to + " DATA FOUND: " + data );

					
					$('#billModal').modal('hide');
					$('#invoice_form')[0].reset(); 

					if( data == 0 ){
						alert("No invoices were gerenated for this dates");
					}else if( data == 1 ){
                        //alert("Redirect to invoice");
                        //window.location.href = "invoice.php";
                        
                        //window.location.href = "invoice.php?id=" + my_id;
                        //window.location.href = "invoice.php?id=id={}&from={}&to={}";

                        //window.open("https://www.w3schools.com");
                        //window.open("https://www.geeksforgeeks.org", "_blank"); 
                        //window.location.replace('https://support.wwf.org.uk');

                        //window.location.href = "invoice.php?id=" + my_id + "&from=" + date_from + "&to=" + date_to;

                         window.open("invoice.php?id=" + my_id + "&from=" + date_from + "&to=" + date_to);

                        //window.open("invoice.php");


					}
					
					
					

				}

			});

						
			


		});


	

	
	/* STATEMENT */
	//#STATEMENT
	$(document).on('click', '.statement', function(){

		//alert("CHECKING ONE TWO THREE");
		//alert(  $(this).attr('id') );

		var statement_id = $(this).attr('id');
		sessionStorage.setItem("_id_now", statement_id);

		$('#statement_hidden_id').val(statement_id);
		$('#statementModal').modal('show');   //DATES FORM
		
		
		

	    
		
	   

	});


	$('#statement_form').on('submit', function(event){
		event.preventDefault();
			

			//alert("HIDDEN ID ATTR: " + $('#statement_hidden_id').val() );

			//statement_date_from    statement_date_to
			var statement_date_from = $('#statement_date_from').val();
			var statement_date_to = $('#statement_date_to').val();

			//var my_id = sessionStorage.getItem("_id_now");
			var statement_id = $('#statement_hidden_id').val();
			//alert( "HIDDEN ID ATTR: " + statement_id + "  DATE FROM: " + statement_date_from + "  DATE TO: " + statement_date_to );
			
			//var statement_id = sessionStorage.getItem("statement_id");
			


			//var form_data = $(this).serialize();
			$.ajax({
				//url:"action.php",
				url:"statement_action.php",
				method:"POST",
				//data:form_data,
				data:{statement_id:statement_id, statement_date_from:statement_date_from, statement_date_to:statement_date_to },
				success:function(data){

					//alert(data);
					//$('#invoice_output').hide();
					//$('#bills_output').hide(); 
					
					
					
					$('#statementModal').modal('hide');
					$('#statement_form')[0].reset(); 

					if( data == 0 ){
						alert("No statements were gerenated for this dates");
					}else if( data == 1 ){
                        //alert("Redirect to STATEMENT");
                        
                        //window.location.href = "statement.php";
                        // window.location.href = "statement.php?id=" + my_id + "&from=" + date_from + "&to=" + date_to;
                        // window.location.href = "statement.php?id=" + statement_id + "&from=" + statement_date_from + "&to=" + statement_date_to;

                        // window.open("invoice.php?id=" + my_id + "&from=" + date_from + "&to=" + date_to);
                         window.open("statement.php?id=" + statement_id + "&from=" + statement_date_from + "&to=" + statement_date_to);

					}

				

					
				}

			});

		
			
		
		});



	    /* APPROVE CREDIT */
		//#APPROVE CREDIT
		/*
		 NOTE: Here i will be procecessing everything in a single button
		 BUTTON [ Approve Credit  (Loads credits)]
		 TB: credits
		- First calculate the invoice amount [ credist * 35 * vat ]
		- add loaded_credits to available_credits
		- save the invoices TB data
		- Then generate a pdf invoice, then send it to the clients_email
		<select name="load_credit" id="load_credit" class="form-control border-color">
				    <option value="10" cred="10">10</option>
				    <option value="20" cred="20">20</option>
				    <option value="30" cred="20">30</option>
				 </select>

		<select name="translanguage" class="translanguage">
		  <option value="0">Please Select Language</option>
		  <option class="transoption" value="1" langid="1">Urdu</option>
		  <option class="transoption" value="2" langid="2">English</option>
		  <option class="transoption" value="3" langid="3">Arabic</option>
		  <option class="transoption" value="4" langid="4">Sindhi</option>
		</select>

		 var value = $(this).find('option:selected').attr("langid");  cred
		 $('#listbox-taskStatus option:selected').data('status');
		 $('#load_credit option:selected').data('cred');
		*/
		$(document).on('click', '.approve', function(){

	        
	        //alert( $( "#load_credit option:selected" ).val() );
			/*
			var statement_id = $(this).attr('id');
			sessionStorage.setItem("statement_id", statement_id);
			//alert( $('#hidden_id').val(id) );
			//$('#apicrudModal').modal('show');
			$('#statementModal').modal('show');
			*/


			var value = $( "#load_credit option:selected" ).val();
			if( value == 0 ){
				alert('Please select credits.');
				location.reload();
				return;
			}//else{}
    	   
        	var approve_id = $(this).attr('id');

        	//var value = $( "#load_credit option:selected" ).val();
        	//var value = $( "#load_credit" ).val();

			$.ajax({
				//url:"action.php",
				url:"approve.php",
				method:"POST",
				//data:form_data,
				data:{approve_id:approve_id, value:value},
				success:function(data){



					
					alert(data);
					location.reload(); 

					//<a href="load.php" target="_blank">Click here</a>
					//REDIRECT TO INVOICE
					// window.open("invoice.php?id=" + my_id + "&from=" + date_from + "&to=" + date_to);
					
				}

			});

			

	



		});



		//CONFIRM PAYMENT
		/*
		Then change the "Pending" stutus "Success"
		*/
		$(document).on('click', '.confirm', function(){

			//alert( $(this).attr('id') );
	
        	var confirm_id = $(this).attr('id');
			$.ajax({
				//url:"action.php",
				url:"confirm.php",
				method:"POST",
				//data:form_data,
				data:{confirm_id:confirm_id},
				success:function(data){
					alert(data);
					location.reload(); 
					
					
				}

			});
				

		});



		//ACTIVATE
		$(document).on('click', '.activate', function(){

			//alert( $(this).attr('id') );
	
			
        	var activate_id = $(this).attr('id');
			$.ajax({
				//url:"action.php",
				url:"activate.php",
				method:"POST",
				//data:form_data,
				data:{activate_id:activate_id},
				success:function(data){
					alert(data);
					location.reload(); 
					
					
				}

			});
			
				

		});




	

 


} );

</script>