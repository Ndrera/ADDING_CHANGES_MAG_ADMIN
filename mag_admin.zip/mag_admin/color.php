<?php
//require('fpdf16/fpdf.php');
require('fpdf182/fpdf.php');

$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Times','I',16);

$pdf->cell(100,10,"This is a cell without background fill",1,1,'C');
$pdf->ln();

$pdf->Cell(100,10,'This is a cell with background fill',1,1,'',true);

$pdf->SetFillColor(976,245,458);
$pdf->ln();
$pdf->cell(100,10,"This is a cell with background fill",1,1,'C',true);

$pdf->Output();
?>