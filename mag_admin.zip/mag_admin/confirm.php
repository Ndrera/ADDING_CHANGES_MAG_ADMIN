<?php
require_once 'core/init.php';


//echo "WE ARE CONFIRMING PAYMENT";
//echo Input::get('confirm_id');

$db = DB::getInstance();

$id = Input::get('confirm_id'); 

//SELECT ba.id FROM branch_additionals ba WHERE ba.branch_id = 6

$data_id = $db->query("SELECT ba.id FROM branch_additionals ba WHERE ba.branch_id = $id");
if( !$data_id->count() ){
	    #NO DATA FOUND IN THE DATABASE
	echo "No invoice data found";

}else{

	 //$x = 1;
	foreach( $data_id->results() as $result ){
		$result->id;
	}

}



try{
	#UPDATE THE CREDIT  
	$db->update( 'branch_additionals', $result->id, array(	

		'payment'      	=> "Success"
		

	) );

	echo "Invoice payment confirmed";

}catch( Exception $e ){
	die( $e->getMessage() );
} 


?>