<?php
//action.php

require_once 'core/init.php';


if( Input::exists() ){
	if( Token::check( Input::get('token') ) ){

		#ADD USER
		if( Input::get('action') == 'add_user' ){
				//echo "WE ARE IN PROCESS MY GUY";
			//echo 1;

			#TRY ONE MORE TIME
			$form_data = array(
				'company_name'     	=> Input::get('company_name'),
				'username'      	=> Input::get('username'),
				'email'  		  	=> Input::get('email'),
				'password'          => Input::get('password'),
				'name'				=> Input::get('name'),
				'password_again'    => Input::get('password_again')
				
			);

			if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on'){
			 #NOTE: HARD CODING IS ALSO  AN OPTION

	         #"https://";
	         $path = str_replace("\\",'/',"https://".$_SERVER['HTTPS_HOST'].substr(getcwd(),strlen($_SERVER['DOCUMENT_ROOT'])));
        	 $api_url = $path . "/api.php?action=add_user"; 

		    }else {

				#"http://";
				 $path = str_replace("\\",'/',"http://".$_SERVER['HTTP_HOST'].substr(getcwd(),strlen($_SERVER['DOCUMENT_ROOT'])));
           		 $api_url = $path . "/api.php?action=add_user";

		    }


			$client =curl_init( $api_url );

			curl_setopt($client, CURLOPT_POST, true);
		    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
		    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

			$response = curl_exec($client);

			curl_close($client);
			
			

			if(  $response == 1 ){
				echo $response;
			}else{
				echo $response;
			}
			


		}



	}
}