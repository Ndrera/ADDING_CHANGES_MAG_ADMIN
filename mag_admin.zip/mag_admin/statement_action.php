<?php
require_once 'core/init.php';

#STATEMENT

//data:{statement_id:statement_id, statement_date_from:statement_date_from, statement_date_to:statement_date_to },
/*
echo Input::get('statement_id');
echo Input::get('statement_date_from');
echo Input::get('statement_date_to');
*/




$output = '';

//{statement_id:statement_id, statement_date_from:statement_date_from, statement_date_to:statement_date_to }
$statement_id = Input::get('statement_id');      #NOTE:IT'S    credit_id
$statement_date_from = Input::get('statement_date_from');
$statement_date_to = Input::get('statement_date_to');


/*
Session::put('statement_id', $statement_id);
Session::put('statement_date_from', $statement_date_from);
Session::put('statement_date_to', $statement_date_to);
*/


//$data = DB::getInstance()->query("SELECT * FROM invoices WHERE (created_at BETWEEN '$statement_date_from' AND '$statement_date_to') AND credit_id = $statement_id ");

$data = DB::getInstance()->query("SELECT * FROM branch_invoice bi 
	INNER JOIN branch_invoice_additionals bia ON bi.id = bia.branch_invoice_id 
	WHERE (date_invoiced BETWEEN '$statement_date_from' AND '$statement_date_to') AND bi.branch_id = $statement_id");


//var_dump(  $data ); die;

if( !$data->count() ){
   
	echo "0";

}else{

	echo "1";

}


echo $output;





?>