<?php
session_start();

$GLOBALS['config'] = array(
	'mysql' => array(
		'host'     => '127.0.0.1',
		'username' => 'root',
		'password' => '',
		'db'       => 'qoutationdb'

	),
	'remember' => array(
		'cookie_name'   => 'hash',
		'cookie_expiry' => 604800

	),
	'session' => array(
		'session_name' => 'user',
		'token_name'   => 'token'
	),

);


#A generic require, using a standar php library
spl_autoload_register( function( $class ){
	require_once 'classes/' . $class . '.php';
});

#Require a sanitize function
require_once 'functions/sanitize.php';




#Process the remember me mechanism
if( Cookie::exists( Config::get('remember/cookie_name') ) &&
   !Session::exists( Config::get('session/session_name') ) ){

	#NOTE: If we delete the "PHPSESSID" and keep the hash. It means we are not logged in but we signify that we want to be remembered.
	#Get the Cookie using the hash check
	$hash = Cookie::get( Config::get('remember/cookie_name') );
	
	$hashCheck = DB::getInstance()->get( 'users_session', array( 
		'hash', '=', $hash
	) );

	if( $hashCheck->count() ){

		#Get the logged in user
		$user = new User( $hashCheck->first()->user_id );
		$user->login();
	}

}